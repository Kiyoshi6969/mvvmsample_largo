package com.example.mvvmsample.retrofit;

import static com.example.mvvmsample.constant.AppConstant.API_KEY;
import com.example.mvvmsample.response.ArticleResponse;
import retrofit2.Call;

import retrofit2.http.GET;

public interface ApiRequest {
    @GET("top-headlines?sources=techcrunh&apiKey"+API_KEY)
    Call<ArticleResponse> getTopHeadlines();
}
