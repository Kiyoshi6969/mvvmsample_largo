package com.example.mvvmsample.repository;


import com.example.mvvmsample.retrofit.ApiRequest;

public class ArticleRepository {
    private static final String TAG = ArticleRepository.class.getSimpleName();
    private final ApiRequest apiRequest;


    public ArticleRepository(ApiRequest apiRequest) {
        this.apiRequest = apiRequest;
    }
}
