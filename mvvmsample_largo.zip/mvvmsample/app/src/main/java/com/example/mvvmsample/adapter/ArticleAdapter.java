package com.example.mvvmsample.adapter;

public class ArticleAdapter {
}
