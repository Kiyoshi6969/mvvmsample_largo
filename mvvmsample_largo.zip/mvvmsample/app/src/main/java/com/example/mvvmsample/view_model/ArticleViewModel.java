package com.example.mvvmsample.view_model;

public class ArticleViewModel {
}
