package com.example.mvvmsample.constant;

public class AppConstant {
    public static final String BASE_URL="https://newsapi.org/v2/";

    public static final String API_KEY="8dbc27e237414939aa45411e5a32cf8b";

}
